
import java.util.Scanner;

public class OnlineResumeBuilder {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Online Resume Builder!");

        // Personal Information
        System.out.print("Enter your full name: ");
        String fullName = scanner.nextLine();

        System.out.print("Enter your email address: ");
        String email = scanner.nextLine();

        System.out.print("Enter your phone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.print("Enter your address: ");
        String address = scanner.nextLine();


        System.out.println("\nEnter your educational details:");
        StringBuilder education = new StringBuilder();
        System.out.print("Enter the School/collage name: ");
        String collage;
        while (!(collage = scanner.nextLine()).equalsIgnoreCase("done")) {
            System.out.print("Enter the department/course: ");
            String department = scanner.nextLine();
            System.out.print("enter CGPA: ");
            String cgpa = scanner.nextLine();                    education.append("-").append(department).append(",").append(collage).append(" (").append(cgpa).append("\n");
            System.out.print("Enter another school/collage or type 'done' to finish: ");
        }

        // Professional Summary
        System.out.print("Enter your professional summary: ");
        String summary = scanner.nextLine();

        // Achievements
        System.out.println("\nEnter your achievements (press Enter after each achievement, type 'done' to finish):");
        StringBuilder achievements = new StringBuilder();
        String achievement;
        while (!(achievement = scanner.nextLine()).equalsIgnoreCase("done")) {
            achievements.append("- ").append(achievement).append("\n");
        }

        // Experience
        System.out.println("\nEnter your work experience:");
        StringBuilder experience = new StringBuilder();
        System.out.print("Enter the company name: ");
        String company;
        while (!(company = scanner.nextLine()).equalsIgnoreCase("done")) {
            System.out.print("Enter the position: ");
            String position = scanner.nextLine();
            System.out.print("Enter the duration: ");
            String duration = scanner.nextLine();
            experience.append("- ").append(position).append(", ").append(company).append(" (").append(duration).append(")\n");
            System.out.print("Enter another company or type 'done' to finish: ");
        }

        // Projects
        System.out.println("\nEnter your projects (press Enter after each project, type 'done' to finish):");
        StringBuilder projects = new StringBuilder();
        String project;
        while (!(project = scanner.nextLine()).equalsIgnoreCase("done")) {
            projects.append("- ").append(project).append("\n");
        }

        // Social Media Links
        System.out.print("\nEnter your social media links (comma-separated): ");
        String socialMediaLinks = scanner.nextLine();

        // Output Resume
        System.out.println("\n===== Resume =====");
        System.out.println("Name: " + fullName);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phoneNumber);
        System.out.println("Address: " + address);
        System.out.println("\nEducation:\n" + education.toString().trim());
        System.out.println("\nProfessional Summary: " + summary);
        System.out.println("\nAchievements:\n" + achievements.toString().trim());
        System.out.println("\nExperience:\n" + experience.toString().trim());
        System.out.println("\nProjects:\n" + projects.toString().trim());
        System.out.println("\nSocial Media Links: " + socialMediaLinks);

        scanner.close();
    }
}


